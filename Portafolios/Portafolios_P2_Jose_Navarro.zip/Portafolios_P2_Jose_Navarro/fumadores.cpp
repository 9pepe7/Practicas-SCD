#include <iostream>
#include <cassert>
#include <thread>
#include <mutex>
#include <random> // dispositivos, generadores y distribuciones aleatorias
#include <chrono> // duraciones (duration), unidades de tiempo
#include "HoareMonitor.h"

using namespace std ;
using namespace HM ;

const int n_fumadores = 3; // Numero de fumadores y de ingredientes distintos



//**********************************************************************
// plantilla de función para generar un entero aleatorio uniformemente
// distribuido entre dos valores enteros, ambos incluidos
// (ambos tienen que ser dos constantes, conocidas en tiempo de compilación)
//----------------------------------------------------------------------

template< int min, int max > int aleatorio()
{
  static default_random_engine generador( (random_device())() );
  static uniform_int_distribution<int> distribucion_uniforme( min, max ) ;
  return distribucion_uniforme( generador );
}

class Estanco : public HoareMonitor {
   private:
   int      num_f ; // número total de fumadores
   CondVar  fum[n_fumadores], est;

   public:
   Estanco( int n ){
     num_f=n;
     for(int i=0; i<num_f; ++i){
       fum[i]=newCondVar();
     }
     est=newCondVar();
   } // constructor
   void ponerIngrediente(const int &i){
     if (fum[i].empty()){
       est.wait();
     }
     fum[i].signal();
   }
   void esperarRecogidaIngrediente(){
     est.wait();
   }
   void obtenerIngrediente(const int &i){
     fum[i].wait();
     est.signal();
   }
};

//----------------------------------------------------------------------
// función que ejecuta la hebra del estanquero

int ProducirIngrediente(){
  chrono::milliseconds duracion(aleatorio<20,200>());
  int i=aleatorio<0,n_fumadores-1>();
  this_thread::sleep_for(duracion);
  return i;
}
void funcion_hebra_estanquero(MRef<Estanco> estanco){
  while (true){
    int i=ProducirIngrediente();
    estanco->ponerIngrediente(i);
    estanco->esperarRecogidaIngrediente();
  }
}

//-------------------------------------------------------------------------
// Función que simula la acción de fumar, como un retardo aleatoria de la hebra

void fumar( int num_fumador ){
   // calcular milisegundos aleatorios de duración de la acción de fumar)
   chrono::milliseconds duracion_fumar( aleatorio<20,200>() );
   // informa de que comienza a fumar
    cout << "Fumador " << num_fumador << "  :"
          << " empieza a fumar (" << duracion_fumar.count() << " milisegundos)" << endl;
   // espera bloqueada un tiempo igual a ''duracion_fumar' milisegundos
   this_thread::sleep_for( duracion_fumar );
   // informa de que ha terminado de fumar
    cout << "Fumador " << num_fumador << "  : termina de fumar, comienza espera de ingrediente." << endl;
}

//----------------------------------------------------------------------
// función que ejecuta la hebra del fumador
void funcion_hebra_fumador(MRef<Estanco> estanco,const int i){
   while(true){
     estanco.obtenerIngrediente(i);
     fumar(i);
   }
}

//----------------------------------------------------------------------

int main()
{
   thread hebra_estanquero(funcion_hebra_estanquero),
          hebras_fumadores [n_fumadores];
   for(int i=0; i<n_fumadores; ++i){
     hebras_fumadores[i]=thread(funcion_hebra_fumador,i);
   }
   hebra_estanquero.join();
   for(int i=0; i<n_fumadores; ++i){
     hebras_fumadores[i].join();
   }
}
